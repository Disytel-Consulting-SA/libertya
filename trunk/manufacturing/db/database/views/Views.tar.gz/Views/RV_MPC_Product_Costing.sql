CREATE OR REPLACE FORCE VIEW RV_MPC_Product_Costing AS 
  SELECT mp.AD_CLIENT_ID, mp.AD_ORG_ID, mp.IsACTIVE, mp.Created, mp.CreatedBy, mp.Updated, mp.UpdatedBy,
mp.M_Product_ID,mp.M_Product_Category_ID, mpc.MPC_Cost_Group_ID,mpc.MPC_Cost_Element_ID,
mpc.M_Warehouse_ID, BOM_Qty_OnHand(mp.M_Product_ID,mpc.M_Warehouse_ID) as QtyonHand,
mpc.CostLLAMT, mpc.CostTLAMT, ( (BOM_Qty_OnHand(mp.M_Product_ID,mpc.M_Warehouse_ID))*(mpc.CostLLAMT + mpc.CostTLAMT)) as TotalAmt,(mpc.CostLLAMT+mpc.CostTLAMT) AS UnitPrice
FROM M_Product mp  INNER JOIN MPC_Product_Costing mpc ON(mpc.M_Product_ID=mp.M_Product_ID)
/ 

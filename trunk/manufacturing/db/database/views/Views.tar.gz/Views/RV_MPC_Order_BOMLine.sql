CREATE OR REPLACE FORCE VIEW RV_MPC_Order_BOMLine AS 
  SELECT
obl.AD_Client_ID ,
obl.AD_Org_ID ,
obl.CreatedBy ,
obl.UpdatedBY ,
obl.Updated ,
obl.Created ,
obl.IsActive ,
obl.MPC_Order_BOM_ID,
obl.MPC_Order_BOMLine_ID  ,
obl.MPC_Order_ID ,
obl.IsCritical ,
obl.IsPacking ,
obl.M_Product_ID  ,
obl.C_UOM_ID  ,
ROUND(obl.QtyRequiered ,4) AS QtyRequiered ,
ROUND(BOM_Qty_Reserved(obl.M_Product_ID,obl.M_Warehouse_ID), 4) AS QtyReserved ,
ROUND(BOM_Qty_Available(obl.M_Product_ID,obl.M_Warehouse_ID),4) AS QtyAvailable ,
ROUND(BOM_Qty_OnHand(obl.M_Product_ID,obl.M_Warehouse_ID),4) AS QtyOnHand  ,
obl.M_Warehouse_ID  ,
ROUND(obl.QtyBom,4) AS QtyBom,
obl.isQtyPercentage ,
ROUND(obl.QtyBatch,4) AS QtyBatch,
DECODE(o.QtyBatchs , 0 , 0 ,  ROUND( obl.QtyRequiered / o.QtyBatchs, 4) ) AS QtyBatchSize
FROM MPC_Order_BOMLine obl INNER JOIN MPC_Order o ON (o.MPC_Order_ID = obl.MPC_Order_ID)
/
 

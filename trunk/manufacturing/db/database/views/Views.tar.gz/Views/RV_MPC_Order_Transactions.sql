CREATE OR REPLACE FORCE VIEW RV_MPC_Order_Transactions AS 
  SELECT DISTINCT o.AD_Client_ID,o.AD_Org_ID, o.IsActive, o.Created, o.CreatedBy, o.UpdatedBy, o.Updated,o.DocumentNo,ol.M_Product_ID, mt.M_Locator_ID,mt.MovementDate,o.MPC_Order_ID,
o.QtyDelivered, o.QtyScrap ,ol.QtyDelivered AS QtyDeliveredLine , (o.QtyDelivered  * ol.QtyBatch)/100 AS QtyIssueShouldbe,
ol.QtyScrap AS QtyScrapLine , (o.QtyScrap  * ol.QtyBatch)/100 AS QtyIssueScrapShouldBe , mt.CreatedBy AS CreatedByIssue, mt.UpdatedBy AS UpdatedByIssue,
(SELECT SUM(t.MovementQty) FROM M_Transaction t WHERE t.MPC_Order_BOMLine_ID=ol.MPC_Order_BOMLine_ID) AS QtyToDeliver,
((((o.QtyDelivered + o.QtyScrap) * ol.QtyBatch)/100) + (SELECT SUM(t.MovementQty) FROM M_Transaction t WHERE t.MPC_Order_BOMLine_ID  = ol.MPC_Order_BOMLine_ID)) AS DifferenceQty
FROM MPC_Order o INNER JOIN MPC_Order_BOMLine ol ON (ol.MPC_Order_ID=o.MPC_Order_ID)  LEFT JOIN M_Transaction mt ON( mt.MPC_Order_BOMLine_ID  = ol.MPC_Order_BOMLine_ID)
/
 

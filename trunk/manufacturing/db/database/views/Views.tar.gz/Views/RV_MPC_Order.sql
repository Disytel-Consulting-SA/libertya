  CREATE OR REPLACE FORCE VIEW RV_MPC_Order AS 
  SELECT o.AD_Client_ID, o.AD_Org_ID,o.IsActive,o.Created, o.CreatedBy, o.Updated, o.UpdatedBy,
o.MPC_Order_ID, o.DocumentNo,o.DocStatus,o.M_Warehouse_ID,o.M_Product_ID,o.QtyEntered,
o.QtyReject,o.QtyScrap,o.QtyBatchs, o.QtyBatchSize,o.DateOrdered, o.DatePromised,o.DateStart,
o.DateStartSchedule,o.DateFinish,o.DateFinishSchedule,o.DateConfirm,o.DateDelivered,o.Lot,
o.MPC_Product_BOM_ID,o.AD_Workflow_ID, (select p.Weight from M_Product p where p.M_Product_ID=o.M_Product_ID) as Weight
FROM MPC_Order o

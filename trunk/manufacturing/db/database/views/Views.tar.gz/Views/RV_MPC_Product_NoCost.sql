CREATE OR REPLACE FORCE VIEW RV_MPC_Product_NoCost AS 
  select pc.AD_Client_ID, pc.AD_Org_ID, pc.IsActive, pc.Created, pc.CreatedBy, pc.UpdatedBy, pc.Updated, pc.MPC_Cost_Element_ID, pc.M_Product_ID, pc.MPC_Cost_Group_ID,
pc.M_Warehouse_ID, pc.S_Resource_ID, pc.CostTLAmt, pc.CostLLAmt, (pc.CostLLAmt + pc.CostTLAmt) AS TotalAmt, p.Value, p.Name,p.M_Product_Category_ID
from MPC_Product_Costing pc inner join M_Product p ON(p.M_Product_ID=pc.M_Product_ID) where exists (select Distinct t.M_Product_ID from M_Transaction t where t.M_Product_ID=pc.M_Product_ID)  and (pc.CostTLAmt =0 and pc.CostLLAmt = 0)
/
 

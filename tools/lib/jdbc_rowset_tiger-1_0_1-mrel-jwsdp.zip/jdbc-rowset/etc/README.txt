etc - Database Initialization program 

    This directory contains common programs that are needed by all the 
 samples in the samples directory. The program here is present to setup
 the database before the samples are run so that all the samples run 
 against a consistent set of data.
 
    The program here also takes 4 parameters they are:
    
      i) The URL of the database to which we have to connect.
     ii) The username for connecting to this database.
    iii) The password for the above username
    iV ) The name of the class that implements the Driver interface.
    
 This program will always be run before all the samples are run.
 
 (c) Sun Microsystems Inc. 2004
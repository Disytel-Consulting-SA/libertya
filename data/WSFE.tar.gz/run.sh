#!/bin/bash

RUTAWSFE="/home/horacio/soft/Archivos"
RUTAPYTHON="/usr/bin/python"
#RUTAPYTHON=`which python`

cd $RUTAWSFE
$RUTAPYTHON $RUTAWSFE/wsfe.py >> $RUTAWSFE/log.error 2>> $RUTAWSFE/log.error

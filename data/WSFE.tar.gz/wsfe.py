#!/usr/bin/python
# -*- coding: latin-1 -*-
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by the
# Free Software Foundation; either version 3, or (at your option) any later
# version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTIBILITY
# or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
# for more details.

"""M�dulo de ejemplo para obtener c�digo de autorizaci�n de impresi�n o 
electr�nico del web service WSFE de AFIP (factura electr�nica)
Basado en wsfe-client.php de Gerardo Fisanotti - DvSHyS/DiOPIN/AFIP - 08-jun-07
Definir WSDL, WSFEURL, TA
Devuelve CAE (C�digo de autorizaci�n de impresi�n o electr�nico de WSFE)
"""

__author__ = "Marcelo Alaniz (alanizmarcelo@gmail.com)"
__copyright__ = "Copyright (C) 2008 Marcelo Alaniz"
__license__ = "LGPL 3.0"
__version__ = "1.0"

import sys, os
from php import date, SimpleXMLElement, SoapClient
import datetime

WSDL = 'wsfe.wsdl'
WSFEURL = "https://wswhomo.afip.gov.ar/wsfe/service.asmx"
#WSFEURL = "https://wsw.afip.gov.ar/wsfe/service.asmx"
SOAP_ACTION = 'http://ar.gov.afip.dif.facturaelectronica/' # Revisar WSDL
SOAP_NS = "http://ar.gov.afip.dif.facturaelectronica/"     # Revisar WSDL 

TA = 'TA.xml'
#CUIT = long(33708113889)


class WSFEError(RuntimeError):
    "Clase para informar errores del WSFE"
    def __init__(self, rerror):
        self.code = str(rerror.percode)
        self.msg = unicode(rerror.perrmsg)

def recuperar_qty(client, token, sign, cuit):
    "Recuperador de cantidad m�xima de registros de detalle"
    results = client.FERecuperaQTYRequest(
        argAuth= {"Token": token, "Sign": sign, "cuit":long(cuit)}
    )
    if int(results.FERecuperaQTYRequestResult.RError.percode) != 0:
        percode = results.FERecuperaQTYRequestResult.RError.percode
	perrmsg = results.FERecuperaQTYRequestResult.RError.perrmsg
        line = str(percode) + "|" + str(perrmsg)
    	try:
           open("error.txt","w").write(line)
        except:
           sys.exit("Error escribiendo error.txt\n")
        print "Percode: %s" % results.FERecuperaQTYRequestResult.RError.percode
        print "MSGerror: %s" % results.FERecuperaQTYRequestResult.RError.perrmsg
        sys.exit(3)
    return int(results.FERecuperaQTYRequestResult.qty.value)
 
def ultnro(client, token, sign, cuit):
    "Recuperador de �ltimo n�mero de transacci�n"
    results = client.FEUltNroRequest(
        argAuth= 
        {
            'Token': token,
            'Sign' : sign,
            'cuit' : cuit
        }
    )

    if int(results.FEUltNroRequestResult.RError.percode) != 0:
        raise WSFEError(results.RError)
    return int(results.FEUltNroRequestResult.nro.value)

def recuperar_last_cmp(client, token, sign, cuit, ptovta, tipocbte):
    "Recuperador de �ltimo n�mero de comprobante"
    results = client.FERecuperaLastCMPRequest(
            argAuth =  
            {
                'Token': token,
                'Sign' : sign,
                'cuit' : cuit
            },
            argTCMP=
            {
                'PtoVta' : ptovta,
                'TipoCbte' : tipocbte
            }
    )
    if int(results.FERecuperaLastCMPRequestResult.RError.percode) != 0:
        raise WSFEError(results.RError)
    return int(results.FERecuperaLastCMPRequestResult.cbte_nro)

def aut(client, token, sign, cuit,id, tipo_doc=0,nro_doc=0,
    tipo_cbte=0, punto_vta=0, cbt_desde=0, cbt_hasta=0,
    imp_total=0, imp_neto=0, impto_liq=0.0,
    imp_tot_conc=0, impto_liq_rni=0, imp_op_ex=0, 
    fecha_cbte=None, fecha_venc_pago=None, 
    presta_serv = 0, fecha_serv_desde=None, fecha_serv_hasta=None, **kwargs ):
    "Facturador (Solicitud de Autorizaci�n de Factura Electr�nica)"
    
    if fecha_cbte is None: fecha_cbte = date('Ymd')
    if fecha_venc_pago is None: fecha_venc_pago = date('Ymd')
    
    detalle = {
        'tipo_doc': tipo_doc,
        'nro_doc':  nro_doc,
        'tipo_cbte': tipo_cbte,
        'punto_vta': punto_vta,
        'cbt_desde': cbt_desde,
        'cbt_hasta': cbt_hasta,
        'imp_total': imp_total,
        'imp_tot_conc': imp_tot_conc,
        'imp_neto': imp_neto,
        'impto_liq': impto_liq,
        'impto_liq_rni': impto_liq_rni,
        'imp_op_ex': imp_op_ex,
        'fecha_cbte': fecha_cbte,
        'fecha_venc_pago': fecha_venc_pago
    }

    if fecha_serv_desde and fecha_serv_hasta:
        detalle['fecha_serv_desde'] = fecha_serv_desde
        detalle['fecha_serv_hasta'] = fecha_serv_hasta
        
    results = client.FEAutRequest(
            argAuth={'Token': token, 'Sign': sign, 'cuit': long(cuit)},
            Fer={
               'Fecr': {'id': id, 'cantidadreg': 1, 'presta_serv': presta_serv},
#                'Fecr': {'cantidadreg': 1, 'presta_serv': presta_serv},
                'Fedr': {'FEDetalleRequest': detalle}
            }
        )

    if int(results.FEAutRequestResult.RError.percode) != 0:
         percode = str(results.FEAutRequestResult.RError.percode)
         perrmsg = str(results.FEAutRequestResult.RError.perrmsg)
    	 try:
            outLine = percode + "|" + perrmsg
            open("error.txt","w").write(outLine)
         except:
            sys.exit("Error escribiendo error.txt\n")
         sys.exit("Error Code: "+percode+", Msg: "+perrmsg)
#        raise WSFEError(results.RError)

    # Resultado: Aceptado o Rechazado
    resultado = str(results.FEAutRequestResult.resultado)
    # Motivo general/del detalle:
    motivo1 = str(results.FEAutRequestResult.motivo)
    if motivo1 in ("NULL", '00'):
        motivo2 = str(results.FEAutRequestResult.FedResp.FEDetalleResponse.motivo)
    reproceso = str(results.FEAutRequestResult.reproceso)
    cae = str(results.FEAutRequestResult.FedResp.FEDetalleResponse.cae)
    fecha_vto = str(results.FEAutRequestResult.FedResp.FEDetalleResponse.fecha_vto)
    #fecha_vto = "%s/%s/%s" % (vto[6:8], vto[4:6], vto[0:4])
    
    return dict(cae=cae, fecha_vto=fecha_vto, resultado=resultado,
                motivo1=motivo1,motivo2=motivo2, reproceso=reproceso)

def dummy(client):
    try:
       results = client.FEDummy()
    except:
    	 try:
            open("error.txt","w").write("Imposible conectarse a la URL")
         except:
            sys.exit("Error escribiendo error.txt\n")
         sys.exit("Imposible conectarse a la URL")

    print "appserver status %s" % results.appserver
    print "dbserver status %s" % results.dbserver
    print "authserver status %s" % results.authserver
#    if is_soap_fault(results):
#        print "Fault: %s" % results.faultcode
#        print "FaultString: %s " % results.faultstring
#        sys.exit(1)
    return
    

def main():

    try:
    	properties = open("properties.ini")
    except:
    	try:
           open("error.txt","w").write("No se puede abrir properties.ini")
        except:
           sys.exit("Error escribiendo error.txt\n")
        sys.exit("Error abriendo properties.ini\n")

    try:
       while True:
          linea = properties.readline()
          splited = linea.rsplit("=")
          name = splited[0]
          if name == 'CUIT':
             var_CUIT = splited[1].rstrip()
             #print "CUIT: %s " % splited[1]
          if name == 'URL_WSFE':
             WSFEURL = splited[1].rstrip()
             #print "URL_WSFE: %s " % splited[1]
          if not linea: break
    except:
      try:
         open("error.txt","w").write("Faltan parametros en el archivo properties.ini")
      except:
         sys.exit("Error escribiendo error.txt\n")
      sys.exit("Faltan parametros en el archivo properties.ini")

    # cliente soap del web service
    client = SoapClient(WSFEURL, 
        action = SOAP_ACTION, 
        namespace = SOAP_NS,
        trace = True)

    # obteniendo el TA
    ta_string = open(TA).read()
    ta = SimpleXMLElement(ta_string)
    token = str(ta.credentials.token)
    sign = str(ta.credentials.sign)

    exp = str(ta.header.expirationTime)
    anio = int(exp[0:4])
    mes = int(exp[5:7])
    dia = int(exp[8:10])
    hh = int(exp[11:13])
    mm = int(exp[14:16])
    ss = int(exp[17:19])
    ahora = datetime.datetime.now()
    expTime = datetime.datetime(anio, mes, dia, hh, mm, ss, 000000)
    if expTime < ahora:
        os.system('python wsaa.py')
#       sys.exit("La fecha del ticket expiro, debe crear uno nuevo llamando a wsaa.py")
#       sys.exit(str(ahora) + " | " + str(expTime))
    # fin TA
    
    try:
    	entrada = open("entrada.txt")
    except:
        try:
           open("error.txt","w").write("Error abriendo entrada.txt")
        except:
           sys.exit("Error escribiendo error.txt\n")
        sys.exit("Error abriendo entrada.txt\n")

    var_numero = entrada.readline()
    var_punto_vta = entrada.readline()
    var_tipo_cbte = entrada.readline()
    var_tipo_doc = entrada.readline()
    var_nro_doc = entrada.readline()
    var_imp_total = entrada.readline()
    var_imp_neto = entrada.readline()
    var_fecha_cbte = entrada.readline()
    var_presta_serv = entrada.readline()
    var_id = entrada.readline()

    #CUIT = sys.argv[1]
    #punto_vta = 5
    #tipo_cbte = 1 # 1: A 6: B
    #numero = sys.argv[2]

    dummy(client)
    
    qty = recuperar_qty(client, token, sign, var_CUIT)
    last_id = ultnro(client, token, sign, var_CUIT)
    actual_id = last_id + 1
    last_cbte = recuperar_last_cmp(client, token, sign, var_CUIT, var_punto_vta, var_tipo_cbte)
    #import pdb; pdb.set_trace()

    if var_id:
       actual_id = var_id

    dic = aut(client, token, sign, var_CUIT, actual_id, tipo_doc=var_tipo_doc,nro_doc=var_nro_doc,
    tipo_cbte=var_tipo_cbte, punto_vta=var_punto_vta, cbt_desde=var_numero, cbt_hasta=var_numero,
    imp_total=var_imp_total, imp_neto=var_imp_neto, impto_liq=0,
    imp_tot_conc=0, impto_liq_rni=0, imp_op_ex=0, 
    fecha_cbte=var_fecha_cbte, fecha_venc_pago=None, 
    presta_serv = var_presta_serv, fecha_serv_desde=None, fecha_serv_hasta=None)
    
    cae = dic['cae']
    motivo1 = dic['motivo1']
    motivo2 = dic['motivo2']
    reproceso = dic['reproceso']
    fecha_vto = dic['fecha_vto']
    resultado = dic['resultado']
    
#    print "QTY: %s" % qty
    print "Last CBTE: %s" % last_cbte
    print "Last Id: %s" % last_id
    print "CAE: %s" % cae
    print "Motivo1: %s" % motivo1
    print "Motivo2: %s" % motivo2
    print "reproceso: %s" % reproceso
    print "Resultado: %s" % resultado

    try:
        salida = str(resultado)+ ":" +str(cae) + ":" + str(last_id+1) +":" +str(motivo2) + ":" + str(reproceso) + ":" + str(fecha_vto) + ":" + str(last_cbte)
        print "salida: %s " %salida
        open("salida.txt","w").write(salida)
        print "El archivo salida.txt se ha generado correctamente."
    except:
        sys.exit("Error escribiendo salida.txt\n")


if __name__ == '__main__':
    main()
